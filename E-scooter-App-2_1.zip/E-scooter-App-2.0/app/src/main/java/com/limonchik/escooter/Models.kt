package com.limonchik.escooter

data class Scooter(val brand: String, val name: String)

/** Семейство протоколов, с которым, скорее всего, говорит модель. */
enum class Family(val title: String, val note: String) {
    M365(
        "Xiaomi M365 / Ninebot G30 (55 AA)",
        "Нет ответа? Проверьте: самокат включён и не подключён к Mi Home / Ninebot (BLE допускает одно подключение); " +
            "на кастомной прошивке должен быть включён BLE-протокол."
    ),
    NINEBOT_ES(
        "Ninebot ES (5A A5)",
        "ES1–ES4 используют собственный протокол Ninebot (часто с шифрованием). Пока не поддерживается."
    ),
    NINEBOT_NEW(
        "Ninebot новые (G2 / F / P)",
        "Новые Ninebot используют шифрованный протокол. Пока не поддерживается: приложение только подключится."
    ),
    XIAOMI_AUTH(
        "Xiaomi 3 / 4 / 5 (авторизация)",
        "Эти модели общаются через Mi Home с авторизацией и шифрованием. Без токена аккаунта данные недоступны; пока не поддерживается."
    ),
    GENERIC(
        "Kugoo / универсальный UART",
        "У Kugoo нет единого протокола: часть моделей — клоны M365 (они заработают), у остальных свой. " +
            "Откройте «Диагностика» и отправьте отчёт боту — так можно добавить вашу модель."
    )
}

data class Profile(val family: Family)

fun profileFor(model: String?): Profile {
    val m = (model ?: "").lowercase()
    val f = when {
        m.contains("kugoo") -> Family.GENERIC
        m.contains("g30") || m.contains("m365") || m.contains("pro 2") ||
            m.contains(" 1s") || m.contains("essential") -> Family.M365
        m.contains("es1") || m.contains("es2") || m.contains("es4") -> Family.NINEBOT_ES
        m.contains("scooter 3") || m.contains("scooter 4") || m.contains("scooter 5") -> Family.XIAOMI_AUTH
        m.contains("g2") || m.contains("f2") || m.contains("f65") || m.contains("p65") -> Family.NINEBOT_NEW
        else -> Family.M365 // «свой вариант»: пробуем самый распространённый протокол (только чтение)
    }
    return Profile(f)
}

object Scooters {
    private fun k(vararg n: String) = n.map { Scooter("Kugoo", it) }
    private fun nb(vararg n: String) = n.map { Scooter("Ninebot", it) }
    private fun x(vararg n: String) = n.map { Scooter("Xiaomi", it) }
    val all: List<Scooter> =
        k("Kugoo M2", "Kugoo M2 Pro", "Kugoo M3", "Kugoo M4", "Kugoo M4 Pro", "Kugoo M4 Pro Plus",
            "Kugoo M5", "Kugoo M5 Pro", "Kugoo M6", "Kugoo M6 Pro", "Kugoo M7", "Kugoo M8",
            "Kugoo G2 Pro", "Kugoo G2 Max", "Kugoo G3 Pro", "Kugoo G4") +
        nb("Ninebot Max G30", "Ninebot Max G30LP", "Ninebot Max G30D", "Ninebot Max G30E",
            "Ninebot Max G2", "Ninebot F2 Pro", "Ninebot ES2", "Ninebot ES4", "Ninebot P65") +
        x("Xiaomi M365", "Xiaomi M365 Pro", "Xiaomi Pro 2", "Xiaomi Mi 1S", "Xiaomi Essential",
            "Xiaomi Mi Electric Scooter 3", "Xiaomi Electric Scooter 4 Pro", "Xiaomi Electric Scooter 5 Pro")
}
