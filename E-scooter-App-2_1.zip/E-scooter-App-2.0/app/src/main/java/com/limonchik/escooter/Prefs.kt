package com.limonchik.escooter

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("escooter", Context.MODE_PRIVATE)
    var scooter: String? get() = sp.getString("scooter", null); set(v) { sp.edit().putString("scooter", v).apply() }
    var username: String? get() = sp.getString("username", null); set(v) { sp.edit().putString("username", v).apply() }
    var lastAddr: String? get() = sp.getString("lastAddr", null); set(v) { sp.edit().putString("lastAddr", v).apply() }
    var onboarded: Boolean get() = sp.getBoolean("onboarded", false); set(v) { sp.edit().putBoolean("onboarded", v).apply() }
    var userAsked: Boolean get() = sp.getBoolean("userAsked", false); set(v) { sp.edit().putBoolean("userAsked", v).apply() }
    var tgPrompted: Boolean get() = sp.getBoolean("tgPrompted", false); set(v) { sp.edit().putBoolean("tgPrompted", v).apply() }
    var theme: Int get() = sp.getInt("theme", 0); set(v) { sp.edit().putInt("theme", v).apply() }
    var mph: Boolean get() = sp.getBoolean("mph", false); set(v) { sp.edit().putBoolean("mph", v).apply() }
}
