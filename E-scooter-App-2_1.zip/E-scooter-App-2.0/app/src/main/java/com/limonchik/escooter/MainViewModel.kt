package com.limonchik.escooter

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel

class MainViewModel(app: Application) : AndroidViewModel(app) {
    val prefs = Prefs(app)
    val ble = BleClient(app)

    var scooter by mutableStateOf(prefs.scooter)
    var onboarded by mutableStateOf(prefs.onboarded)
    var theme by mutableIntStateOf(prefs.theme)
    var mph by mutableStateOf(prefs.mph)
    var showTg by mutableStateOf(false)
    var scanOpen by mutableStateOf(false)
    val userAsked get() = prefs.userAsked

    init {
        // Telegram prompt: exactly once, ever (flag is saved the moment it is shown)
        if (!prefs.tgPrompted) { showTg = true; prefs.tgPrompted = true }
        ble.onConnected = { prefs.lastAddr = it }
    }

    fun dismissTg() { showTg = false }
    fun setScooter(n: String) { scooter = n; prefs.scooter = n }
    fun saveUser(u: String) { prefs.username = u.trim().removePrefix("@") }
    fun finishOnboarding() { prefs.userAsked = true; prefs.onboarded = true; onboarded = true }
    fun changeScooter() { onboarded = false }
    fun setTheme(i: Int) { theme = i; prefs.theme = i }
    fun setMph(v: Boolean) { mph = v; prefs.mph = v }
    fun openScan() { scanOpen = true; ble.startScan() }
    fun closeScan() { scanOpen = false; ble.stopScan() }
    fun connect(addr: String) { scanOpen = false; ble.connect(addr) }
    fun autoConnect() {
        val a = prefs.lastAddr ?: return
        val st = ble.state.value
        if ((st == ConnState.IDLE || st == ConnState.ERROR) && !ble.userDisconnected) ble.connect(a)
    }

    override fun onCleared() { ble.close() }
}
